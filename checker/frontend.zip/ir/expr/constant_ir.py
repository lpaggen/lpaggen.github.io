from __future__ import annotations
from abc import abstractmethod
from dataclasses import dataclass
from types import EllipsisType

from common.span import SourceSpan
from generated import _pb2
from ir.expr.expr_ir import ExprIR


@dataclass
class ConstantIR(ExprIR):
    value: object
    # not including "kind" field because it seems like legacy metadata

    @abstractmethod
    def to_proto(self):
        raise NotImplementedError


@dataclass
class BooleanIR(ConstantIR):
    value: bool
    span: SourceSpan

    def __repr__(self):
        return "true" if self.value is True else "false"

    def to_proto(self):
        return _pb2.ExprIR(
            constant=_pb2.ConstantIR(
                bool_lit=_pb2.BooleanIR(
                    value=self.value,
                    span=self.span.to_proto(),
                )
            )
        )

@dataclass
class BytesIR(ConstantIR):
    value: bytes
    span: SourceSpan

    def to_proto(self):
        return _pb2.ExprIR(
            constant=_pb2.ConstantIR(
                bytes_lit=_pb2.BytesIR(
                    value=self.value,
                    span=self.span.to_proto(),
                )
            )
        )

@dataclass
class ComplexIR(ConstantIR):
    real: float
    imag: float
    span: SourceSpan | None

    def to_proto(self):
        return _pb2.ExprIR(
            constant=_pb2.ConstantIR(
                complex_lit=_pb2.ComplexIR(
                    real=self.real,
                    imag=self.imag,
                    span=self.span.to_proto() if self.span is not None else None,
                )
            )
        )


@dataclass
class EllipsisIR(ConstantIR):
    value: EllipsisType
    span: SourceSpan

    def to_proto(self):
        return _pb2.ExprIR(
            constant=_pb2.ConstantIR(
                ellipsis_lit=_pb2.EllipsisIR(
                    span=self.span.to_proto(),
                )
            )
        )


@dataclass
class IntegerIR(ConstantIR):
    value: int
    span: SourceSpan

    def __repr__(self):
        return str(self.value)

    def to_proto(self):
        return _pb2.ExprIR(
            constant=_pb2.ConstantIR(
                integer_lit=_pb2.IntegerIR(
                    value=self.value,
                    span=self.span.to_proto(),
                )
            )
        )


@dataclass
class NoneIR(ConstantIR):
    value: None
    span: SourceSpan | None

    def to_proto(self):
        return _pb2.ExprIR(
            constant=_pb2.ConstantIR(
                none_lit=_pb2.NoneIR(
                    span=self.span.to_proto(),
                )
            )
        )


@dataclass
class FloatIR(ConstantIR):
    value: float
    span: SourceSpan

    def __repr__(self):
        return str(self.value)

    def to_proto(self):
        return _pb2.ExprIR(
            constant=_pb2.ConstantIR(
                float_lit=_pb2.FloatIR(
                    value=self.value,
                    span=self.span.to_proto(),
                )
            )
        )


@dataclass
class StringIR(ConstantIR):
    value: str
    span: SourceSpan

    def __repr__(self):
        return self.value

    def to_proto(self):
        return _pb2.ExprIR(
            constant=_pb2.ConstantIR(
                string_lit=_pb2.StringIR(
                    value=self.value,
                    span=self.span.to_proto(),
                )
            )
        )
