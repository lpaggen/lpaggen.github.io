from __future__ import annotations
from enum import IntEnum

class Conversion(IntEnum):
    NONE = -1
    STR = ord("s")
    REPR = ord("r")
    ASCII = ord("a")
